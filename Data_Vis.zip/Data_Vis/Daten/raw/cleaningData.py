import pandas as pd

# Daten aus der CSV-Datei laden
csv_path = '/Users/student/Downloads/world-data-2023.csv'
data = pd.read_csv(csv_path)

# Ausgewählte Spalten definieren
selected_columns = [
    'Country', 'GDP', 'Population: Labor force participation (%)', 'Population', 'Unemployment rate',
    'Tax revenue (%)', 'Total tax rate', 'CPI', 'CPI Change (%)', 'Fertility Rate',
    'Birth Rate', 'Life expectancy', 'Gross primary education enrollment (%)',
    'Gross tertiary education enrollment (%)', 'Out of pocket health expenditure'
]
filtered_data = data[selected_columns]


# Bereinigen von Währungs- und Prozentsymbolen und Umwandeln in numerische Typen
filtered_data['GDP'] = filtered_data['GDP'].str.replace('[\$,]', '', regex=True).astype(float)
filtered_data['Population']=filtered_data['Population'].str.replace('[\$,]', '', regex=True).astype(float)

# Bereinigen der Daten, einschließlich der Umwandlung von Prozentsätzen und Berechnung von BIP pro Kopf
filtered_data['CPI'] = pd.to_numeric(filtered_data['CPI'], errors='coerce')

percent_columns = [
    'Population: Labor force participation (%)', 'Unemployment rate', 'Tax revenue (%)',
    'Total tax rate', 'CPI Change (%)', 'Gross primary education enrollment (%)',
    'Gross tertiary education enrollment (%)', 'Out of pocket health expenditure'
]
for column in percent_columns:
    filtered_data[column] = filtered_data[column].str.replace('%', '').astype(float) / 100

# Konvertieren anderer numerischer Spalten, die möglicherweise als Objekt gelesen wurden

# Berechnung des BIP pro Kopf
filtered_data['GDP per Capita'] = filtered_data['GDP'] / filtered_data['Population']


# Bereinigte Daten speichern
output_path = '/Users/student/Data_Vis/Daten/cleaned/gefilterte_Daten.csv'
filtered_data.to_csv(output_path, index=False)


# Überprüfen der bereinigten Daten
print(filtered_data.info())
