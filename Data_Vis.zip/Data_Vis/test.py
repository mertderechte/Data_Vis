# project-name/
# │
# ├── data/
# │   ├── raw/               # Rohdaten, unverändert
# │   └── processed/        # Bereinigte und verarbeitete Daten
# │
# ├── notebooks/
# │   ├── 01_data_cleaning.ipynb  # Notebook für Datenbereinigung
# │   ├── 02_data_analysis.ipynb  # Notebook für Datenanalyse
# │   └── 03_visualization.ipynb  # Notebook für die Erstellung der Visualisierungen
# │
# ├── src/
# │   ├── __init__.py        # Macht src zu einem Python-Modul
# │   └── utils.py           # Hilfsfunktionen, die in den Notebooks verwendet werden können
# │
# ├── docs/
# │   ├── project_documentation.md  # Detaillierte Projektdokumentation
# │   └── images/             # Bilder und Diagramme für die Dokumentation
# │
# ├── tests/
# │   ├── __init__.py
# │   └── test_utils.py      # Tests für die Utility-Funktionen
# │
# ├── .gitignore             # Spezifiziert, welche Dateien und Ordner Git ignorieren soll
# ├── README.md              # Hauptdokumentationsdatei für das Projekt
# └── requirements.txt       # Liste aller benötigten Python-Bibliotheken
