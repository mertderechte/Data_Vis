import dash
from dash import dcc, html
from dash.dependencies import Input, Output
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

# Import the visualization functions
from a1_life_Streudiagramm import return_lifeScatter
from a2_fertility_StreuDiagramm import return_fertilityScatter
from a3_Landkarte import returnLandkarte

# Load daten 
data = pd.read_csv('Daten/cleaned/gefilterte_Daten.csv')


app = dash.Dash(__name__, suppress_callback_exceptions=True)#hier wird das Dash initialisiert 


app.layout = html.Div([# das ist der Layout des Dashboards, bzw. die Basisansicht 
    html.H1("Die Analyse der Auswirkungen des Bruttoinlandsproduktes", style={'textAlign': 'center'}),# die Überschrift des Dashboardes
    dcc.Tabs(id='tabs', value='tab-1', children=[# verschiedene Tabs, um zwischen den verschiednenen Visualisierungen zu wechseln 
        dcc.Tab(label='Lebenserwartung und BIP', value='tab-1'),
        dcc.Tab(label='Fruchtbarkeitsrate und BIP', value='tab-2'),
        dcc.Tab(label='Höchstwerte von ökonomischen und anderen Indikatoren', value='tab-3'),
        dcc.Tab(label='Interaktive Weltkarte des BIP', value='tab-4'),
        dcc.Tab(label='Interaktive Analyse der Kenngrößen', value='tab-5'),
    ]),
    html.Div(id='tabs-content')# Inhalte der TAbs, also die Visualisierungen werden gerendert durch den Container
])# die id ist wichtig, damit der Inhalt aktualisiert wird bei Änderungen, wie z.B. bei der Filterfunktion. 
#mithilfe der ID kann die Callback Funktion auf das html.Div Element zugreifen und den Inhalt aktualisieren, bzw. den inhalt des Tabs zu aktualisieren 
@app.callback(Output('tabs-content', 'children'),
              [Input('tabs', 'value')])
def render_content(tab):
    if tab == 'tab-1':
        return html.Div([
            dcc.Graph(figure=return_lifeScatter())
        ])
    elif tab == 'tab-2':
        return html.Div([
            dcc.Graph(figure=return_fertilityScatter())
        ])
    elif tab == 'tab-3':
        return html.Div([
            html.H2("Wählen Sie eine Kenngröße für die Top-5-Länder"),
            dcc.Dropdown(
                id='indicator-dropdown',
                options=[{'label': col, 'value': col} for col in data.select_dtypes(include=['number']).columns],
                value='GDP'  # Standardmäßig gewählte Kenngröße
            ),
            dcc.Graph(id='top-5-lollipop')
        ])
    elif tab == 'tab-4':
        return html.Div([
            dcc.Graph(figure=returnLandkarte())
        ])
    elif tab == 'tab-5':
        return html.Div([
            html.H2("Kenngrößen nach Land: Stand 2023"),
            dcc.Dropdown(
                id='country-dropdown',
                options=[{'label': country, 'value': country} for country in data['Country'].unique()],
                value='Germany'  # das land, was zu beginn angezeigt wird 
            ),
            dcc.Dropdown(
                id='indicators-dropdown-5',
                options=[{'label': col, 'value': col} for col in data.select_dtypes(include=['number']).columns],
                multi=True,
                value=['GDP']  # Standardmäßig gewählte Kenngröße
            ),
            dcc.Graph(id='country-data-visualization'),
            html.Div(id='no-data-alert')
        ])

@app.callback(
    Output('top-5-lollipop', 'figure'),
    [Input('indicator-dropdown', 'value')]
)
def update_lollipop(selected_indicator):
    numeric_data = data[['Country', selected_indicator]].copy()
    if '%' in selected_indicator:
        numeric_data[selected_indicator] *= 100
    top_5 = numeric_data.nlargest(5, selected_indicator).sort_values(by=selected_indicator, ascending=False)
    top_5['Rank'] = range(1, 6)  # Add a rank column with the highest value as 1

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=top_5[selected_indicator],
        y=[f"{rank}. {country}" for rank, country in zip(top_5['Rank'], top_5['Country'])],
        marker=dict(color='LightSkyBlue', size=10),
        mode='markers',
        name='Top 5 Länder'
    ))

    fig.add_trace(go.Bar(
        x=top_5[selected_indicator],
        y=[f"{rank}. {country}" for rank, country in zip(top_5['Rank'], top_5['Country'])],
        orientation='h',
        marker=dict(color='PowderBlue'),
        name='Länder',
        textposition='inside'
    ))
    
    fig.update_layout(
        title_text=f'Top 5 Länder nach {selected_indicator}',
        xaxis_title='Kenngrößen',
        yaxis_title='Land',
        yaxis=dict(
            autorange='reversed'  # Ensure the highest value is at the top
        ),
        xaxis={'type': 'log' if selected_indicator == 'GDP' else 'linear'}
    )
    
    return fig

@app.callback(
    [Output('country-data-visualization', 'figure'),
     Output('no-data-alert', 'children')],
    [Input('country-dropdown', 'value'),
     Input('indicators-dropdown-5', 'value')]
)
def update_graph(selected_country, selected_indicators):
    filtered_data = data[data['Country'] == selected_country]
    if filtered_data.empty:
        return px.bar(), "Leider wurden keine Daten zu diesem Land erhoben."
    else:
        filtered_data = filtered_data[['Country'] + selected_indicators]
        filtered_data = filtered_data.melt(id_vars='Country', var_name='Category', value_name='Value')
        fig = px.bar(
            filtered_data,
            x='Category',
            y='Value',
            title=f'Daten für {selected_country}',
            log_y=True,
            color_discrete_sequence=px.colors.qualitative.Pastel
        )
        return fig, ""

# Run the application
if __name__ == '__main__':
    app.run_server(debug=True)
