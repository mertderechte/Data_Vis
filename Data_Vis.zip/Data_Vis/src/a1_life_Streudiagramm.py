import pandas as pd
import plotly.graph_objects as go
import plotly.express as px

# Laden der Daten
data = pd.read_csv('/Users/student/Data_Vis/Daten/cleaned/gefilterte_Daten.csv')


# Erstellung eines Graph-Objects
fig = go.Figure()

# Scatter-Plot
fig.add_trace(go.Scatter(
    x=data['GDP per Capita'],
    y=data['Life expectancy'],
    mode='markers',
    marker=dict(
        size=9,
        color=data['Life expectancy'],# Farbe ist basierend auf Lebenserwartung
        colorscale=px.colors.sequential.Viridis, 
        #hier wären auch andere Farbskalen möglich: Beispielsweise inferno,cividis oder Plasma
        # am angenehmsten fande ich aber viridis 
        showscale=True # Farbskala  an der Seite des Diagramms
    ),
    text=data['Country']# Tooltip-> Anzeige Länder
))

#Informationen wie titel,etc. angeben
fig.update_layout(
    title='Die Beziehung zwischen der Lebenserwartung und dem Bruttoinlandsprodukt pro Kopf',
    xaxis_title='Bruttoinlandsprodukt pro Kopf in Dollar',
    yaxis_title='Lebenserwartung in Jahren',
    paper_bgcolor='white',
    plot_bgcolor='white',
    template='plotly_white'
)
def return_lifeScatter():
    return fig 
#hier wird die Methode definiert, die das zuvor erstellte Objekt des Graphen zurückgibt. 
# Diese Methode wird bei der Dashanwendung aufgerufen, wenn man auf das entsprechende Tab drückt 


#das fig.show ist nicht mehr nötig, da beim aufruf des dash direkt das Objekt der figur returned  wird und im Dash angezeigt wird 
#fig.show()
