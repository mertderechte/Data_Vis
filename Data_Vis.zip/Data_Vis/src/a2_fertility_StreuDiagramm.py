import pandas as pd
import plotly.express as px

# Laden der Daten
data = pd.read_csv('/Users/student/Data_Vis/Daten/cleaned/gefilterte_Daten.csv')

# Erstellen des Scatter-Plots mit Plotly Express
fig = px.scatter(
    data_frame=data,
    x='GDP per Capita',
    y='Fertility Rate',
    #Plotly.express erstellt selbst trendlinie, gibt nur lowess an als methode
    trendline='lowess', # kurvige Trendlinie erstellen, damit durchschnitt und Aussage klar wird
    color='Fertility Rate', #Die Farbe orientiert sich an die durchschnittliche Kinderanzahl der Frau 
    hover_name='Country', # Tooltip, der die Namen der Länder anzeigt
    title='Die Beziehung zwischen der durchschnittlichen Kinderanzahl pro Frau und dem Bruttoinlandsprodukt pro Kopf', # klare Beschreibung, dass kinderanzahl statt Fruchtbarkeit, damit keine Missverständnisse entstehen 
    labels={'GDP per Capita': 'BIP pro Kopf', 'Fertility Rate': 'Kinderanzahl pro Frau'}, #ursprüngliche Spaltennamen durch Selbstgewählte umgeändert
    template='plotly_white',
    color_continuous_scale=px.colors.sequential.Viridis # Farbskala wählen für Optik, damit angenehm
    # man könnte auch andere farbskala, aber einheitliche verwendung ist besser 
)

# Anpassen des Layouts des Plots
fig.update_layout(
    xaxis_title='Bruttoinlandsprodukt pro Kopf',
    xaxis_type='log', # logarithmische x -Achse, damit die werte nicht so verzerrt sind durch hohe BIP pro Kopf
    yaxis_title='Durchschnittliche Kinderanzahl pro Frau',
    plot_bgcolor='white',

)

fig.update_xaxes(showgrid=True, gridwidth=1, gridcolor='lightgrey')
fig.update_yaxes(showgrid=True, gridwidth=1, gridcolor='lightgrey')


# Hinzufügen einer Legende da die ABkürzung BIP im Tooltip vorkommt
fig.add_annotation(
    text="BIP: Bruttoinlandsprodukt",
    xref="paper", yref="paper",
    x=1, y=1.05,
    showarrow=False,
    font=dict(size=15, color="black"),
    align="right"
)

# Funktion, die das Figure-Objekt zurückgibt
def return_fertilityScatter():
    return fig
#erneut wird Methode definiert, die Grafik Objekt zurückgibt um das dann anzuzeigen, in der Dashanwendung

#das fig.show ist nicht mehr nötig, da beim aufruf des dash direkt das Objekt der figur returned wird und im Dash angezeigt wird 
#fig.show()
