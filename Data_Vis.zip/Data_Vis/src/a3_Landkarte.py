import pandas as pd
import plotly.express as px
import numpy as np

# Daten laden
data = pd.read_csv('/Users/student/Data_Vis/Daten/cleaned/gefilterte_Daten.csv')

# Quantile berechnen, um diese in die FArbskala einzubinden. 
# Dadurch kann später ein Kontrast bei den Ländern je nach Höhe des BIPs entstehen 
# dadurch wird die Farbskala nicht verzerrt
quantile_low = data['GDP'].quantile(0.25)
quantile_middle = data['GDP'].quantile(0.50)
quantile_high = data['GDP'].quantile(0.75)
quantile_very_high = data['GDP'].quantile(0.90)

# Erstellung der thematischen Karte mit Plotly Express
fig = px.choropleth(
    data_frame=data,
    locations='Country',# Angabe der Spalte, welche die Namen der Länder enthält 
    locationmode='country names',
    color='GDP',  # Die Farben der Länder sind abhängig von der Höhe des BIPs
    color_continuous_scale=px.colors.sequential.Viridis,  # Farbskala Viridis wie die vorherigen Visualisierungen 
    range_color=[quantile_low, quantile_very_high],  # Einteilung der FArbskala in die Quantile, um einen guten Farbkontrast zu gewähren
    title='Das Bruttoinlandsprodukt der Länder im internationalen Vergleich',

    labels={'GDP': 'Höhe des Bruttoinlandsprodukt','Country':'Land'},
    hover_data={'Country': True, 'GDP': True}# Beim drüberhovern sollen diese beiden Kenngrößen angezeigt werden
    # das ist der Tooltip, der den Namen des jeweiligen Landes sowie die Höhe des BIPs angibt
)

#Farbskala erstellen, die nicht verzerrt ist. 
fig.update_layout(
    margin={"r":0, "t":50, "l":0, "b":0},
    coloraxis_colorbar=dict(
        title='Bruttoinlandsprudukt im durchschnittlichen Vergleich',# Name der Farbskala 
        ticks='outside',# die einzelnen bezeichnungen der Farbe sollen nicht in dem Balken selbst sein 
        tickvals=[quantile_low, quantile_middle, quantile_high, quantile_very_high],# Anzeige der einzelnen Farbeinstufungen 
        ticktext=['Gering', 'Mittel', 'Hoch', 'Sehr hoch'],# Die Bezeichnungen für die Ticks, also den 
    
    )
)


# Funktion zur Rückgabe der Landkarte
def returnLandkarte():
    return fig

# Optional: fig.show() zum Testen der Visualisierung im Jupyter Notebook
#fig.show()
